<?php
require_once 'config.php';
requireLogin();
$page = 'reports';

require_once __DIR__ . '/reports/ReportGenerator.php';

$employeeCount = $conn->query('SELECT COUNT(*) as c FROM employees')->fetch_assoc()['c'];
$inventoryValue = $conn->query('SELECT SUM(stock * price) as v FROM products')->fetch_assoc()['v'];
$purchaseValue = $conn->query('SELECT SUM(total_amount) as v FROM purchases')->fetch_assoc()['v'];
$salesValue = $conn->query('SELECT SUM(total_amount) as v FROM sales')->fetch_assoc()['v'];

$reportData = [
    'employee_count' => (int)($employeeCount ?? 0),
    'inventory_value' => (float)($inventoryValue ?? 0),
    'purchase_value' => (float)($purchaseValue ?? 0),
    'sales_value' => (float)($salesValue ?? 0),
    'summary' => 'Predicted demand for timber and furniture products is increasing in the current season. Focus on fast-moving products and replenish low-stock items before they run out.'
];

$reportMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['send_report']) || isset($_POST['download_report']))) {
    $isDownload = isset($_POST['download_report']);
    $reportPath = __DIR__ . '/reports/woodsync-report-' . date('YmdHis') . '.pdf';
    $content = ReportGenerator::buildPdfContent($reportData);

    if (ReportGenerator::savePdf($reportPath, $content)) {
        if ($isDownload) {
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . basename($reportPath) . '"');
            readfile($reportPath);
            exit;
        }

        $to = trim($_POST['email'] ?? '');
        $subject = 'WoodSync ERP Report';
        $body = "Please find the attached WoodSync ERP report.\n\n" . $content;
        $headers = "From: woodsync@example.com\r\n";

        $emailSent = false;
        if ($to !== '') {
            $emailSent = @mail($to, $subject, $body, $headers);
        }

        if ($emailSent) {
            $reportMessage = 'Report sent successfully.';
        } else {
            $reportMessage = 'Report generated locally, but email delivery is not configured on this server.';
        }
    } else {
        $reportMessage = 'Unable to generate the report file.';
    }
}

include 'includes/header.php';
?>
<?php if ($reportMessage): ?>
    <div class="alert alert-success"><?= e($reportMessage) ?></div>
<?php endif; ?>
<section class="report-hero">
    <div>
        <h1>Executive Report</h1>
        <p>WoodSync ERP delivers a concise business overview with key operational and financial metrics for informed decision-making.</p>
    </div>
    <div class="report-meta">
        <strong>Prepared for:</strong> WoodSync Leadership
        <span>Report date: <?= e(date('F j, Y')) ?></span>
    </div>
</section>

<div class="card-grid">
    <div class="stat-card">
        <span class="metric-label">Active Employees</span>
        <span class="metric-value"><?= e($employeeCount) ?></span>
        <p class="metric-note">Workforce supporting production and service operations.</p>
    </div>
    <div class="stat-card">
        <span class="metric-label">Inventory Value</span>
        <span class="metric-value">₹<?= e(number_format((float)($inventoryValue ?? 0), 2)) ?></span>
        <p class="metric-note">Estimated value of stock on hand.</p>
    </div>
    <div class="stat-card">
        <span class="metric-label">Total Purchases</span>
        <span class="metric-value">₹<?= e(number_format((float)($purchaseValue ?? 0), 2)) ?></span>
        <p class="metric-note">Expenditure on procurement to date.</p>
    </div>
    <div class="stat-card">
        <span class="metric-label">Total Sales</span>
        <span class="metric-value">₹<?= e(number_format((float)($salesValue ?? 0), 2)) ?></span>
        <p class="metric-note">Revenue generated from completed orders.</p>
    </div>
</div>

<div class="report-layout">
    <div class="panel report-summary">
        <div class="panel-header">
            <div>
                <h3>Executive Summary</h3>
                <p class="subtle">A focused performance synopsis with strategic recommendations.</p>
            </div>
        </div>
        <p>Predicted demand for timber and furniture products is increasing in the current season. Focus on fast-moving products and replenish low-stock items before they run out.</p>
    </div>

    <div class="panel report-actions">
        <div class="panel-header">
            <div>
                <h3>Report Distribution</h3>
                <p class="subtle">Export or share this executive report with stakeholders.</p>
            </div>
        </div>
        <form method="post" class="form-grid report-form">
            <div>
                <label>Email Address</label>
                <input type="email" name="email" placeholder="leader@woodsync.com" required>
            </div>
            <div class="form-actions">
                <button type="submit" name="download_report" value="1">Download PDF</button>
                <button type="submit" name="send_report" value="1" class="button-soft">Generate &amp; Send Report</button>
            </div>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>