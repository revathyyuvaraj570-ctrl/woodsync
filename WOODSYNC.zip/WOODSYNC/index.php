<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
        $stmt = $conn->prepare('SELECT id, name, email, role, password FROM users WHERE email = ?');
        if ($stmt) {
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['role'] = $user['role'];
                header('Location: dashboard.php');
                exit;
            }

            setFlash('error', 'Invalid login credentials.');
        } else {
            setFlash('error', 'Database error: unable to prepare login query.');
        }
    } else {
        setFlash('error', 'Database is not available. Start MySQL in XAMPP and try again.');
    }
}

$page = 'login';
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WoodSync ERP Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="login-container">
    <div class="login-card">
        <h1>WoodSync ERP</h1>
        <p>Login to manage timber, furniture, and hardware operations.</p>
        <?php if ($flash): ?>
            <div class="alert alert-error"><?= e($flash['message']) ?></div>
        <?php endif; ?>
        <?php if (!empty($_SESSION['db_error'])): ?>
            <div class="alert alert-error"><?= e($_SESSION['db_error']) ?></div>
        <?php endif; ?>
        <form method="post">
            <label>Email</label>
            <input type="email" name="email" required>
            <label>Password</label>
            <input type="password" name="password" required>
            <br><br>
            <button type="submit">Login</button>
        </form>
    </div>
</div>
</body>
</html>
