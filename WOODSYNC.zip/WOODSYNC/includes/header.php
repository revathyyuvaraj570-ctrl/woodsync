<?php
if (!isset($page)) {
    $page = 'dashboard';
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WoodSync ERP</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="page-shell">
    <aside class="sidebar">
        <div class="brand">
            <h1>WoodSync</h1>
            <p>ERP for Timber & Furniture</p>
        </div>
        <nav>
            <a class="nav-link <?= $page === 'dashboard' ? 'active' : '' ?>" href="dashboard.php">Dashboard</a>
            <a class="nav-link <?= $page === 'employees' ? 'active' : '' ?>" href="employees.php">Employees</a>
            <a class="nav-link <?= $page === 'inventory' ? 'active' : '' ?>" href="inventory.php">Inventory</a>
            <a class="nav-link <?= $page === 'purchases' ? 'active' : '' ?>" href="purchases.php">Purchases</a>
            <a class="nav-link <?= $page === 'sales' ? 'active' : '' ?>" href="sales.php">Sales</a>
            <a class="nav-link <?= $page === 'reports' ? 'active' : '' ?>" href="reports.php">Reports</a>
            <a class="nav-link <?= $page === 'profile' ? 'active' : '' ?>" href="profile.php">Profile</a>
            <a class="nav-link" href="logout.php">Logout</a>
        </nav>
    </aside>
    <main class="main-content">
        <header class="topbar">
            <div>
                <h2>WoodSync ERP</h2>
                <p>Smart operations for timber, furniture, and hardware businesses.</p>
            </div>
            <div class="topbar-user">
                <span><?= e($_SESSION['name'] ?? 'User') ?></span>
                <span class="badge"><?= e($_SESSION['role'] ?? 'Employee') ?></span>
            </div>
        </header>
