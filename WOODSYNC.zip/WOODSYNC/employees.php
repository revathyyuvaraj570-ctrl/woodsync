<?php
require_once 'config.php';
requireLogin();
$page = 'employees';

$editId = (int)($_GET['edit_id'] ?? 0);
$editEmployee = null;
if ($editId) {
    $editStmt = $conn->prepare('SELECT * FROM employees WHERE id = ?');
    $editStmt->bind_param('i', $editId);
    $editStmt->execute();
    $editEmployee = $editStmt->get_result()->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode = $_POST['mode'] ?? 'add';
    $id = (int)($_POST['id'] ?? 0);
    $fullName = trim($_POST['full_name'] ?? '');
    $position = trim($_POST['position'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $salary = (float)($_POST['salary'] ?? 0);

    if ($mode === 'edit' && $id) {
        $stmt = $conn->prepare('UPDATE employees SET full_name = ?, position = ?, email = ?, phone = ?, department = ?, salary = ? WHERE id = ?');
        $stmt->bind_param('sssssdi', $fullName, $position, $email, $phone, $department, $salary, $id);
        $stmt->execute();
        setFlash('success', 'Employee updated successfully.');
    } else {
        $employeeInsertColumns = ['full_name', 'position', 'email', 'phone', 'department', 'salary'];
        $employeeInsertValues = [$fullName, $position, $email, $phone, $department, $salary];
        $employeeInsertTypes = 'sssssd';

        $legacyColumns = $conn->query("SHOW COLUMNS FROM employees WHERE Field IN ('user_id', 'employee_code', 'designation')");
        if ($legacyColumns) {
            while ($column = $legacyColumns->fetch_assoc()) {
                if ($column['Field'] === 'user_id') {
                    $employeeInsertColumns[] = 'user_id';
                    $employeeInsertValues[] = (int)($_SESSION['user_id'] ?? 0);
                    $employeeInsertTypes .= 'i';
                } elseif ($column['Field'] === 'employee_code') {
                    $employeeInsertColumns[] = 'employee_code';
                    $employeeInsertValues[] = 'EMP' . date('ymdHis') . random_int(100, 999);
                    $employeeInsertTypes .= 's';
                } elseif ($column['Field'] === 'designation') {
                    $employeeInsertColumns[] = 'designation';
                    $employeeInsertValues[] = $position;
                    $employeeInsertTypes .= 's';
                }
            }
        }

        $columnList = implode(', ', $employeeInsertColumns);
        $placeholders = implode(', ', array_fill(0, count($employeeInsertValues), '?'));
        $stmt = $conn->prepare("INSERT INTO employees ($columnList) VALUES ($placeholders)");
        if ($stmt) {
            $stmt->bind_param($employeeInsertTypes, ...$employeeInsertValues);
            $stmt->execute();
            setFlash('success', 'Employee added successfully.');
        } else {
            setFlash('error', 'Unable to add employee: ' . $conn->error);
        }
    }
    header('Location: employees.php');
    exit;
}

if (isset($_GET['delete_id'])) {
    $deleteId = (int)$_GET['delete_id'];
    $deleteStmt = $conn->prepare('DELETE FROM employees WHERE id = ?');
    $deleteStmt->bind_param('i', $deleteId);
    $deleteStmt->execute();
    setFlash('success', 'Employee deleted successfully.');
    header('Location: employees.php');
    exit;
}

$result = $conn->query('SELECT * FROM employees ORDER BY id ASC');
$flash = getFlash();
include 'includes/header.php';
?>
<?php if ($flash): ?>
    <div class="alert <?= $flash['type'] === 'error' ? 'alert-error' : 'alert-success' ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
<div class="panel">
    <h3><?= $editEmployee ? 'Edit Employee' : 'Add Employee' ?></h3>
    <form method="post" class="form-grid">
        <input type="hidden" name="mode" value="<?= $editEmployee ? 'edit' : 'add' ?>">
        <?php if ($editEmployee): ?><input type="hidden" name="id" value="<?= e($editEmployee['id']) ?>"><?php endif; ?>
        <div><label>Full Name</label><input type="text" name="full_name" value="<?= e($editEmployee['full_name'] ?? '') ?>" required></div>
        <div><label>Position</label><input type="text" name="position" value="<?= e($editEmployee['position'] ?? '') ?>" required></div>
        <div><label>Email</label><input type="email" name="email" value="<?= e($editEmployee['email'] ?? '') ?>" required></div>
        <div><label>Phone</label><input type="text" name="phone" value="<?= e($editEmployee['phone'] ?? '') ?>" required></div>
        <div><label>Department</label><input type="text" name="department" value="<?= e($editEmployee['department'] ?? '') ?>" required></div>
        <div><label>Salary (₹)</label><input type="number" step="0.01" name="salary" value="<?= e($editEmployee['salary'] ?? 0) ?>" required></div>
        <div style="grid-column: 1 / -1;"><button type="submit"><?= $editEmployee ? 'Update Employee' : 'Save Employee' ?></button></div>
    </form>
</div>

<div class="panel">
    <h3>Employee List</h3>
    <div class="table-wrap">
        <table>
            <thead><tr><th>#</th><th>Name</th><th>Position</th><th>Department</th><th>Phone</th><th>Salary</th><th>Actions</th></tr></thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= e($row['id']) ?></td>
                        <td><?= e($row['full_name'] ?? $row['employee_code'] ?? '') ?></td>
                        <td><?= e($row['position'] ?? $row['designation'] ?? '') ?></td>
                        <td><?= e($row['department'] ?? '') ?></td>
                        <td><?= e($row['phone'] ?? '') ?></td>
                        <td>₹<?= e(number_format((float)$row['salary'], 2)) ?></td>
                        <td class="row-actions">
                            <a class="action-btn edit" href="employees.php?edit_id=<?= e($row['id']) ?>">Edit</a>
                            <a class="action-btn delete" href="employees.php?delete_id=<?= e($row['id']) ?>" onclick="return confirm('Delete this employee?')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include 'includes/footer.php'; ?>