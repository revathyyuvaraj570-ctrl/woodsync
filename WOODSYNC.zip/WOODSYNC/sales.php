<?php
require_once 'config.php';
requireLogin();
$page = 'sales';

$submittedSale = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // handle delete-all action
    if (!empty($_POST['delete_all_sales'])) {
        // clear session pending sales
        unset($_SESSION['pending_sales']);
        if ($dbReady) {
            $conn->query('DELETE FROM sales');
            $conn->query('ALTER TABLE sales AUTO_INCREMENT = 1');
            setFlash('success', 'All sales deleted from database.');
        } else {
            setFlash('success', 'All local (unsaved) sales cleared.');
        }
    }

    // handle delete single action first
    // handle delete action first
    if (!empty($_POST['delete_sale_id'])) {
        $delId = $_POST['delete_sale_id'];
        // remove local pending sale
        if (strpos($delId, 'local-') === 0) {
            $pending = &$_SESSION['pending_sales'];
            if (!empty($pending) && is_array($pending)) {
                foreach ($pending as $k => $p) {
                    if (($p['id'] ?? '') === $delId) {
                        unset($pending[$k]);
                        $_SESSION['pending_sales'] = array_values($pending);
                        setFlash('success', 'Local sale removed.');
                        break;
                    }
                }
            }
        } else {
            // attempt DB delete
            if ($dbReady && is_numeric($delId)) {
                $delStmt = $conn->prepare('DELETE FROM sales WHERE id = ?');
                if ($delStmt) {
                    $delStmt->bind_param('i', $delId);
                    if ($delStmt->execute()) {
                        // if it was previously marked for pending delete, remove that mark
                        $pendingDeletes = $_SESSION['pending_sales_deletes'] ?? [];
                        if (!empty($pendingDeletes)) {
                            $pendingDeletes = array_values(array_filter($pendingDeletes, function($v) use ($delId){ return $v != $delId; }));
                            $_SESSION['pending_sales_deletes'] = $pendingDeletes;
                        }
                        setFlash('success', 'Sale deleted.');
                    } else {
                        setFlash('error', 'Unable to delete sale: ' . $delStmt->error);
                    }
                }
            } elseif (!$dbReady && is_numeric($delId)) {
                // mark for deletion when DB is back
                $pendingDeletes = $_SESSION['pending_sales_deletes'] ?? [];
                if (!in_array($delId, $pendingDeletes, true)) {
                    $pendingDeletes[] = $delId;
                    $_SESSION['pending_sales_deletes'] = $pendingDeletes;
                }
                setFlash('success', 'Sale marked for deletion; it will be removed when the database is available.');
            } else {
                setFlash('error', 'Invalid sale id for deletion.');
            }
        }
    }
    if (!empty($_POST['delete_all_sales']) || !empty($_POST['delete_sale_id'])) {
        header('Location: sales.php');
        exit;
    }
    $customerName = trim($_POST['customer_name'] ?? '');
    $productName = trim($_POST['product_name'] ?? '');
    $quantity = (int)($_POST['quantity'] ?? 0);
    $totalAmount = (float)($_POST['total_amount'] ?? 0);
    $soldOn = trim($_POST['sold_on'] ?? date('Y-m-d'));

    $saved = false;
    $saveError = null;

    if ($dbReady) {
        $customerId = null;
        if ($customerName !== '') {
            $customerCheck = $conn->prepare('SELECT id FROM customers WHERE name = ? LIMIT 1');
            if ($customerCheck) {
                $customerCheck->bind_param('s', $customerName);
                $customerCheck->execute();
                $customerRow = $customerCheck->get_result()->fetch_assoc();
                if ($customerRow) {
                    $customerId = (int)$customerRow['id'];
                } else {
                    $customerInsert = $conn->prepare('INSERT INTO customers (name) VALUES (?)');
                    if ($customerInsert) {
                        $customerInsert->bind_param('s', $customerName);
                        $customerInsert->execute();
                        $customerId = (int)$customerInsert->insert_id;
                    }
                }
            }
        }

        if ($customerId === null) {
            $stmt = $conn->prepare('INSERT INTO sales (product_name, quantity, total_amount, sold_on) VALUES (?, ?, ?, ?)');
            $stmt->bind_param('sids', $productName, $quantity, $totalAmount, $soldOn);
        } else {
            $stmt = $conn->prepare('INSERT INTO sales (customer_id, product_name, quantity, total_amount, sold_on) VALUES (?, ?, ?, ?, ?)');
            $stmt->bind_param('isids', $customerId, $productName, $quantity, $totalAmount, $soldOn);
        }

        if ($stmt && $stmt->execute()) {
            $saved = true;
        } else {
            $saveError = $stmt ? $stmt->error : 'Unable to save sale.';
        }
    } else {
        $saveError = $dbError ?: 'Database is unavailable.';
    }

    if ($saved) {
        $submittedSale = [
            'id' => 'db-' . time(),
            'customer_name' => $customerName !== '' ? $customerName : '',
            'product_name' => $productName,
            'quantity' => $quantity,
            'total_amount' => $totalAmount,
            'sold_on' => $soldOn,
            'saved_locally' => false
        ];
        setFlash('success', 'Sale recorded.');
    } else {
        $submittedSale = [
            'id' => 'local-' . time(),
            'customer_name' => $customerName !== '' ? $customerName : '',
            'product_name' => $productName,
            'quantity' => $quantity,
            'total_amount' => $totalAmount,
            'sold_on' => $soldOn,
            'saved_locally' => true
        ];
        $_SESSION['pending_sales'][] = $submittedSale;
        setFlash('error', 'Saved locally on this page because the database is unavailable.');
    }
}

$customersResult = $dbReady ? $conn->query('SELECT * FROM customers ORDER BY id') : false;
$customers = [];
$customerNameColumn = null;
if ($customersResult) {
    $customersColumnCheck = $conn->query("SHOW COLUMNS FROM customers LIKE 'name'");
    if ($customersColumnCheck && $customersColumnCheck->num_rows > 0) {
        $customerNameColumn = 'name';
    } elseif ($conn->query("SHOW COLUMNS FROM customers LIKE 'customer_name'")) {
        $customerNameColumn = 'customer_name';
    }

    while ($customer = $customersResult->fetch_assoc()) {
        $customerDisplayName = '';
        if ($customerNameColumn && isset($customer[$customerNameColumn])) {
            $customerDisplayName = $customer[$customerNameColumn];
        }
        if ($customerDisplayName === '') {
            $customerDisplayName = 'Customer #' . ($customer['id'] ?? '');
        }
        $customers[] = [
            'id' => $customer['id'] ?? null,
            'name' => $customerDisplayName
        ];
    }
}

$salesTableExists = false;
$customersTableExists = false;
$customersNameColumnExists = false;
$salesTableCheck = $dbReady ? $conn->query("SHOW TABLES LIKE 'sales'") : false;
if ($salesTableCheck && $salesTableCheck->num_rows > 0) {
    $salesTableExists = true;
    $customersTableCheck = $conn->query("SHOW TABLES LIKE 'customers'");
    if ($customersTableCheck && $customersTableCheck->num_rows > 0) {
        $customersTableExists = true;
        $customersNameCheck = $conn->query("SHOW COLUMNS FROM customers LIKE 'name'");
        if ($customersNameCheck && $customersNameCheck->num_rows > 0) {
            $customersNameColumnExists = true;
        }
    }
}

$salesData = [];
$totalSales = 0.0;
$totalInvoices = 0;
$salesError = null;

if ($salesTableExists) {
    $salesQuery = $customersTableExists && $customersNameColumnExists
        ? 'SELECT s.*, c.name AS customer_name FROM sales s LEFT JOIN customers c ON c.id = s.customer_id ORDER BY s.id ASC'
        : 'SELECT s.*, s.customer_id AS customer_name FROM sales s ORDER BY s.id ASC';

    $salesResult = $conn->query($salesQuery);
    if ($salesResult) {
        while ($saleRow = $salesResult->fetch_assoc()) {
            if (empty($saleRow['customer_name']) && !empty($saleRow['customer_id'])) {
                $saleRow['customer_name'] = 'Customer #' . $saleRow['customer_id'];
            }
            $salesData[] = $saleRow;
            $totalSales += (float)$saleRow['total_amount'];
            $totalInvoices++;
        }
    } else {
        $salesError = $conn->error ?: 'Unable to read sales data.';
    }
} else {
    $salesError = 'The sales table is not available yet.';
}
$pendingSales = $_SESSION['pending_sales'] ?? [];
if ($submittedSale) {
    if (!empty($submittedSale['saved_locally'])) {
        $pendingSales[] = $submittedSale;
        $_SESSION['pending_sales'] = $pendingSales;
    }
}
if (!empty($pendingSales)) {
    $salesData = array_merge($pendingSales, $salesData);
}

// filter out any DB rows that were marked for deletion while offline
$pendingDeletes = $_SESSION['pending_sales_deletes'] ?? [];
if (!empty($pendingDeletes)) {
    $salesData = array_values(array_filter($salesData, function($r) use ($pendingDeletes){
        $id = $r['id'] ?? '';
        if (is_numeric($id) && in_array((int)$id, $pendingDeletes, true)) return false;
        return true;
    }));
}

$averageSale = $totalInvoices ? $totalSales / $totalInvoices : 0;
$recentTrend = array_slice($salesData, 0, 6);
$trendMax = 1;
$peakSale = ['sold_on' => '-', 'total_amount' => 0];
foreach ($recentTrend as $trendSale) {
    $trendMax = max($trendMax, (float)$trendSale['total_amount']);
    if ((float)$trendSale['total_amount'] > (float)$peakSale['total_amount']) {
        $peakSale = $trendSale;
    }
}
include 'includes/header.php';
?>
<style>
/* Hover actions for sales table rows */
</style>
<?php if (!empty($salesError)): ?>
<div class="alert alert-error">Unable to load sales data: <?= e($salesError) ?></div>
<?php endif; ?>
<div class="stats-grid">
    <div class="stat-card">
        <span class="metric-label">Total Sales</span>
        <span class="metric-value">₹<?= e(number_format($totalSales, 2)) ?></span>
    </div>
    <div class="stat-card">
        <span class="metric-label">Invoices</span>
        <span class="metric-value"><?= e($totalInvoices) ?></span>
    </div>
    <div class="stat-card">
        <span class="metric-label">Avg Sale</span>
        <span class="metric-value">₹<?= e(number_format($averageSale, 2)) ?></span>
    </div>
    <div class="stat-card">
        <span class="metric-label">Recent Sale</span>
        <span class="metric-value"><?= e($salesData[0]['sold_on'] ?? date('Y-m-d')) ?></span>
    </div>
</div>

<div class="sales-layout">
    <div class="panel">
        <h3>Create Invoice</h3>
        <form method="post" class="form-grid">
            <div><label>Customer</label><input type="text" name="customer_name" list="customers-list" placeholder="Type customer name" autocomplete="off"></div>
            <datalist id="customers-list">
                <?php foreach ($customers as $customer): ?>
                    <option value="<?= e($customer['name']) ?>"><?= e($customer['name']) ?></option>
                <?php endforeach; ?>
            </datalist>
            <div><label>Product</label><input type="text" name="product_name" required></div>
            <div><label>Quantity</label><input type="number" name="quantity" required></div>
            <div><label>Total Amount (₹)</label><input type="number" step="0.01" name="total_amount" required></div>
            <div><label>Date</label><input type="date" name="sold_on" value="<?= date('Y-m-d') ?>" required></div>
            <div style="grid-column: 1 / -1;"><button type="submit">Save Sale</button></div>
        </form>
    </div>

    <div class="panel">
        <h3>Sales History</h3>
        <div class="table-wrap">
            <table>
                <thead><tr><th>#</th><th>Customer</th><th>Product</th><th>Quantity</th><th>Total</th><th>Date</th><th>Actions</th></tr></thead>
</div>

<div style="margin-top:12px;">
    <form method="post" onsubmit="return confirm('Delete ALL sales? This cannot be undone.');">
        <input type="hidden" name="delete_all_sales" value="1">
        <button type="submit" class="action-btn delete">Delete All Sales</button>
    </form>
</div>
                <tbody>
                    <?php foreach ($salesData as $row): ?>
                        <tr>
                            <td><?= e($row['id'] ?? 'local') ?></td>
                            <td><?= e(!empty($row['customer_name']) ? $row['customer_name'] : 'Walk-in Customer') ?></td>
                            <td><?= e($row['product_name'] ?? '') ?></td>
                            <td><?= e($row['quantity'] ?? 0) ?></td>
                            <td>₹<?= e(number_format((float)($row['total_amount'] ?? 0), 2)) ?></td>
                            <td><?= e($row['sold_on'] ?? date('Y-m-d')) ?></td>
                            <td class="row-actions">
                                <a class="action-btn edit" href="sales_edit.php?id=<?= urlencode($row['id'] ?? '') ?>">Edit</a>
                                <form method="post" style="display:inline" onsubmit="return confirm('Delete this sale?');">
                                    <input type="hidden" name="delete_sale_id" value="<?= e($row['id'] ?? '') ?>">
                                    <button type="submit" class="action-btn delete">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>