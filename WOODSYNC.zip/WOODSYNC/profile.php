<?php
require_once 'config.php';
requireLogin();
$page = 'profile';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare('UPDATE users SET name = ?, password = ? WHERE id = ?');
        $stmt->bind_param('ssi', $name, $hash, $_SESSION['user_id']);
    } else {
        $stmt = $conn->prepare('UPDATE users SET name = ? WHERE id = ?');
        $stmt->bind_param('si', $name, $_SESSION['user_id']);
    }

    $stmt->execute();
    $_SESSION['name'] = $name;
    setFlash('success', 'Profile updated.');
    header('Location: profile.php');
    exit;
}

$user = $conn->query('SELECT name, email, role FROM users WHERE id = ' . (int)$_SESSION['user_id'])->fetch_assoc();
include 'includes/header.php';
?>
<div class="panel">
    <h3>My Profile</h3>
    <form method="post" class="form-grid">
        <div><label>Name</label><input type="text" name="name" value="<?= e($user['name']) ?>" required></div>
        <div><label>Email</label><input type="email" value="<?= e($user['email']) ?>" disabled></div>
        <div><label>Role</label><input type="text" value="<?= e($user['role']) ?>" disabled></div>
        <div><label>New Password</label><input type="password" name="password"></div>
        <div style="grid-column: 1 / -1;"><button type="submit">Update Profile</button></div>
    </form>
</div>
<?php include 'includes/footer.php'; ?>