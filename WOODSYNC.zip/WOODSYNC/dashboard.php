<?php
require_once 'config.php';
requireLogin();

$page = 'dashboard';

function fetchSingleValue($sql, $default = 0)
{
    global $conn;
    $result = $conn->query($sql);
    if (!$result) {
        error_log("Database query failed: " . $conn->error . " - SQL: " . $sql);
        return $default;
    }
    $row = $result->fetch_assoc();
    return $row ? ($row[array_keys($row)[0]] ?? $default) : $default;
}

$totalEmployees = fetchSingleValue('SELECT COUNT(*) as total_employees FROM employees');
$totalProducts = fetchSingleValue('SELECT COUNT(*) as total_products FROM products');
$lowStock = fetchSingleValue('SELECT COUNT(*) as low_stock FROM products WHERE stock < 10');
$sales = fetchSingleValue('SELECT SUM(total_amount) as sales FROM sales', 0);

include 'includes/header.php';
?>
<div class="card-grid">
    <div class="card">
        <h3>Total Employees</h3>
        <p><?= e($totalEmployees) ?></p>
    </div>
    <div class="card">
        <h3>Total Products</h3>
        <p><?= e($totalProducts) ?></p>
    </div>
    <div class="card">
        <h3>Low Stock Alerts</h3>
        <p><?= e($lowStock) ?></p>
    </div>
    <div class="card">
        <h3>Sales Summary</h3>
        <p>₹<?= e(number_format((float)($sales ?? 0), 2)) ?></p>
    </div>
</div>

<div class="panel">
    <h3>Recent Activity</h3>
    <p>Welcome to WoodSync ERP. Track employees, inventory, purchases, and sales from one polished wood-themed dashboard.</p>
</div>
<?php include 'includes/footer.php'; ?>
