<?php
session_start();

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

$host = '127.0.0.1';
$user = 'root';
$pass = '';
$dbname = 'woodsync_erp';
$port = 3306;
$connectTimeout = 5;

mysqli_report(MYSQLI_REPORT_OFF);
$conn = mysqli_init();
mysqli_options($conn, MYSQLI_OPT_CONNECT_TIMEOUT, $connectTimeout);
$connected = @mysqli_real_connect($conn, $host, $user, $pass, $dbname, $port);
$dbReady = true;
$dbError = null;

if (!$connected || $conn->connect_errno) {
    $dbReady = false;
    $dbError = 'Database connection failed: ' . ($conn->connect_error ?: mysqli_connect_error());
} else {
    $conn->query("CREATE DATABASE IF NOT EXISTS `$dbname`");
    if (!$conn->select_db($dbname)) {
        $dbReady = false;
        $dbError = 'Unable to select database: ' . $conn->error;
    } else {
        $schema = file_get_contents(__DIR__ . '/database/schema.sql');
        if ($schema) {
            if (!$conn->multi_query($schema)) {
                $dbError = 'Schema setup failed: ' . $conn->error;
            } else {
                do {
                    if ($result = $conn->store_result()) {
                        $result->free();
                    }
                } while ($conn->more_results() && $conn->next_result());
            }
        }

        $conn->query("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(100) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, role ENUM('Admin','Employee') DEFAULT 'Employee', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB");

        $conn->query("CREATE TABLE IF NOT EXISTS employees (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(100) NOT NULL,
            position VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            department VARCHAR(100) NOT NULL,
            salary DECIMAL(10,2) DEFAULT 0.00,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB");

        $expectedColumns = [
            'name' => "VARCHAR(100) NOT NULL AFTER id",
            'email' => "VARCHAR(100) NOT NULL UNIQUE AFTER name",
            'password' => "VARCHAR(255) NOT NULL AFTER email",
            'role' => "ENUM('Admin','Employee') DEFAULT 'Employee' AFTER password"
        ];

        foreach ($expectedColumns as $column => $definition) {
            $colCheck = $conn->query("SHOW COLUMNS FROM users LIKE '$column'");
            if (!$colCheck || $colCheck->num_rows === 0) {
                $conn->query("ALTER TABLE users ADD COLUMN $column $definition");
            }
        }

        $employeeColumns = [
            'full_name' => "VARCHAR(100) NOT NULL AFTER id",
            'position' => "VARCHAR(100) NOT NULL AFTER full_name",
            'email' => "VARCHAR(100) NOT NULL AFTER position",
            'phone' => "VARCHAR(20) NOT NULL AFTER email",
            'department' => "VARCHAR(100) NOT NULL AFTER phone",
            'salary' => "DECIMAL(10,2) DEFAULT 0.00 AFTER department"
        ];

        foreach ($employeeColumns as $column => $definition) {
            $colCheck = $conn->query("SHOW COLUMNS FROM employees LIKE '$column'");
            if (!$colCheck || $colCheck->num_rows === 0) {
                $conn->query("ALTER TABLE employees ADD COLUMN $column $definition");
            }
        }

        // Ensure products table has commonly expected columns for compatibility
        $productColumns = [
            'name' => "VARCHAR(100) NOT NULL AFTER id",
            'stock' => "INT NOT NULL DEFAULT 0 AFTER category_id",
            'price' => "DECIMAL(10,2) DEFAULT 0.00 AFTER stock",
            'supplier' => "VARCHAR(100) DEFAULT NULL AFTER price"
        ];

        foreach ($productColumns as $column => $definition) {
            $colCheck = $conn->query("SHOW COLUMNS FROM products LIKE '$column'");
            if (!$colCheck) {
                // products table might not exist yet — try to create fallback table
                $conn->query("CREATE TABLE IF NOT EXISTS products (id INT AUTO_INCREMENT PRIMARY KEY) ENGINE=InnoDB");
                $colCheck = $conn->query("SHOW COLUMNS FROM products LIKE '$column'");
            }
            if ($colCheck && $colCheck->num_rows === 0) {
                $conn->query("ALTER TABLE products ADD COLUMN $column $definition");
            }
        }

        // Migrate existing alternate column names if present
        $hasProductName = (bool)$conn->query("SHOW COLUMNS FROM products LIKE 'product_name'")->num_rows;
        $hasUnitPrice = (bool)$conn->query("SHOW COLUMNS FROM products LIKE 'unit_price'")->num_rows;
        $hasCurrentStock = (bool)$conn->query("SHOW COLUMNS FROM products LIKE 'current_stock'")->num_rows;

        if ($hasProductName) {
            $conn->query("UPDATE products SET name = product_name WHERE (name IS NULL OR name = '') AND product_name IS NOT NULL");
        }
        if ($hasUnitPrice) {
            $conn->query("UPDATE products SET price = unit_price WHERE (price IS NULL OR price = 0) AND unit_price IS NOT NULL");
        }
        if ($hasCurrentStock) {
            $conn->query("UPDATE products SET stock = current_stock WHERE (stock IS NULL OR stock = 0) AND current_stock IS NOT NULL");
        }

        $adminEmail = 'woodsync@gmail.com';
        $adminCheck = $conn->query("SELECT id FROM users WHERE email = '$adminEmail'");
        if ($adminCheck && $adminCheck->num_rows === 0) {
            $adminPassword = password_hash('erp123', PASSWORD_BCRYPT);
            $adminInsert = $conn->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
            if ($adminInsert) {
                $adminName = 'Revathy';
                $adminRole = 'Admin';
                $adminInsert->bind_param('ssss', $adminName, $adminEmail, $adminPassword, $adminRole);
                $adminInsert->execute();
            } else {
                $dbReady = false;
                $dbError = 'Unable to prepare admin insert: ' . $conn->error;
            }
        } elseif (!$adminCheck) {
            $dbReady = false;
            $dbError = 'Unable to check admin account: ' . $conn->error;
        }
    }
}

if (!$dbReady) {
    $_SESSION['db_error'] = $dbError;
} else {
    unset($_SESSION['db_error']);
}

function requireLogin()
{
    if (!isset($_SESSION['user_id'])) {
        header('Location: index.php');
        exit;
    }
}

function isAdmin()
{
    return ($_SESSION['role'] ?? '') === 'Admin';
}

function setFlash($type, $message)
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash()
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }

    return null;
}

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
