<?php
require_once 'config.php';
requireLogin();
$page = 'inventory';

$editId = (int)($_GET['edit_id'] ?? 0);
$editProduct = null;
if ($editId) {
    $editStmt = $conn->prepare('SELECT * FROM products WHERE id = ?');
    $editStmt->bind_param('i', $editId);
    $editStmt->execute();
    $editProduct = $editStmt->get_result()->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode = $_POST['mode'] ?? 'add';
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    $supplier = trim($_POST['supplier'] ?? '');

    if ($mode === 'edit' && $id) {
        $stmt = $conn->prepare('UPDATE products SET name = ?, category_id = ?, stock = ?, price = ?, supplier = ? WHERE id = ?');
        $stmt->bind_param('siidsi', $name, $categoryId, $stock, $price, $supplier, $id);
        $stmt->execute();
        setFlash('success', 'Product updated successfully.');
    } else {
        $stmt = $conn->prepare('INSERT INTO products (name, category_id, stock, price, supplier) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('siids', $name, $categoryId, $stock, $price, $supplier);
        $stmt->execute();
        setFlash('success', 'Product added successfully.');
    }
    header('Location: inventory.php');
    exit;
}

if (isset($_GET['delete_id'])) {
    $deleteId = (int)$_GET['delete_id'];
    $deleteStmt = $conn->prepare('DELETE FROM products WHERE id = ?');
    $deleteStmt->bind_param('i', $deleteId);
    $deleteStmt->execute();
    setFlash('success', 'Product deleted successfully.');
    header('Location: inventory.php');
    exit;
}

$categories = $conn->query('SELECT * FROM categories ORDER BY name');
$products = $conn->query('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id ORDER BY p.id ASC');
$flash = getFlash();
include 'includes/header.php';
?>
<?php if ($flash): ?>
    <div class="alert <?= $flash['type'] === 'error' ? 'alert-error' : 'alert-success' ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
<div class="panel">
    <h3><?= $editProduct ? 'Edit Product' : 'Add Product' ?></h3>
    <form method="post" class="form-grid">
        <input type="hidden" name="mode" value="<?= $editProduct ? 'edit' : 'add' ?>">
        <?php if ($editProduct): ?><input type="hidden" name="id" value="<?= e($editProduct['id']) ?>"><?php endif; ?>
        <div><label>Product Name</label><input type="text" name="name" value="<?= e($editProduct['name'] ?? $editProduct['product_name'] ?? '') ?>" required></div>
        <div><label>Category</label><select name="category_id">
            <?php while ($cat = $categories->fetch_assoc()): ?>
                <option value="<?= e($cat['id']) ?>" <?= (($editProduct['category_id'] ?? '') == $cat['id']) ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
            <?php endwhile; ?>
        </select></div>
        <div><label>Stock</label><input type="number" name="stock" value="<?= e($editProduct['stock'] ?? $editProduct['current_stock'] ?? 0) ?>" required></div>
        <div><label>Price (₹)</label><input type="number" step="0.01" name="price" value="<?= e($editProduct['price'] ?? $editProduct['unit_price'] ?? 0) ?>" required></div>
        <div><label>Supplier</label><input type="text" name="supplier" value="<?= e($editProduct['supplier'] ?? '') ?>"></div>
        <div style="grid-column: 1 / -1;"><button type="submit"><?= $editProduct ? 'Update Product' : 'Save Product' ?></button></div>
    </form>
</div>

<div class="panel">
    <h3>Inventory</h3>
    <div class="table-wrap">
        <table>
            <thead><tr><th>#</th><th>Name</th><th>Category</th><th>Stock</th><th>Price</th><th>Supplier</th><th>Actions</th></tr></thead>
            <tbody>
                <?php if ($products): ?>
                    <?php while ($row = $products->fetch_assoc()): ?>
                        <tr>
                            <td><?= e($row['id'] ?? '') ?></td>
                            <td><?= e($row['name'] ?? $row['product_name'] ?? '') ?></td>
                            <td><?= e($row['category_name'] ?? '') ?></td>
                            <td><?= e($row['stock'] ?? $row['qty'] ?? 0) ?></td>
                            <td>₹<?= e(number_format((float)($row['price'] ?? $row['unit_price'] ?? 0), 2)) ?></td>
                            <td><?= e($row['supplier'] ?? $row['supplier_name'] ?? '') ?></td>
                            <td class="row-actions">
                                <a class="action-btn edit" href="inventory.php?edit_id=<?= e($row['id']) ?>">Edit</a>
                                <a class="action-btn delete" href="inventory.php?delete_id=<?= e($row['id']) ?>" onclick="return confirm('Delete this product?')">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No products found or database error.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include 'includes/footer.php'; ?>