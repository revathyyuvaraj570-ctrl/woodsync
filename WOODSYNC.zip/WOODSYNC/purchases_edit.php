<?php
require_once 'config.php';
requireLogin();

$id = $_REQUEST['id'] ?? '';
$isLocal = strpos($id, 'local-') === 0;
$purchase = null;

if ($isLocal) {
    $pendingPurchases = $_SESSION['pending_purchases'] ?? [];
    foreach ($pendingPurchases as $pendingPurchase) {
        if (($pendingPurchase['id'] ?? '') === $id) {
            $purchase = $pendingPurchase;
            break;
        }
    }
} elseif ($dbReady && is_numeric($id)) {
    $stmt = $conn->prepare('SELECT p.*, s.name AS supplier_name FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ? LIMIT 1');
    if ($stmt) {
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $purchase = $stmt->get_result()->fetch_assoc();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $purchase) {
    $supplierName = trim($_POST['supplier_name'] ?? '');
    $productName = trim($_POST['product_name'] ?? '');
    $quantity = (int)($_POST['quantity'] ?? 0);
    $totalAmount = (float)($_POST['total_amount'] ?? 0);
    $purchasedOn = trim($_POST['purchased_on'] ?? date('Y-m-d'));

    if ($isLocal) {
        foreach ($_SESSION['pending_purchases'] as $key => $pendingPurchase) {
            if (($pendingPurchase['id'] ?? '') === $id) {
                $_SESSION['pending_purchases'][$key]['supplier_name'] = $supplierName;
                $_SESSION['pending_purchases'][$key]['product_name'] = $productName;
                $_SESSION['pending_purchases'][$key]['quantity'] = $quantity;
                $_SESSION['pending_purchases'][$key]['total_amount'] = $totalAmount;
                $_SESSION['pending_purchases'][$key]['purchased_on'] = $purchasedOn;
                break;
            }
        }
        setFlash('success', 'Local purchase updated.');
    } elseif ($dbReady && is_numeric($id)) {
        $supplierId = null;
        if ($supplierName !== '') {
            $supplierCheck = $conn->prepare('SELECT id FROM suppliers WHERE name = ? LIMIT 1');
            if ($supplierCheck) {
                $supplierCheck->bind_param('s', $supplierName);
                $supplierCheck->execute();
                $supplierRow = $supplierCheck->get_result()->fetch_assoc();
                if ($supplierRow) {
                    $supplierId = (int)$supplierRow['id'];
                } else {
                    $supplierInsert = $conn->prepare('INSERT INTO suppliers (name) VALUES (?)');
                    if ($supplierInsert) {
                        $supplierInsert->bind_param('s', $supplierName);
                        $supplierInsert->execute();
                        $supplierId = (int)$supplierInsert->insert_id;
                    }
                }
            }
        }

        if ($supplierId === null) {
            $update = $conn->prepare('UPDATE purchases SET supplier_id = NULL, product_name = ?, quantity = ?, total_amount = ?, purchased_on = ? WHERE id = ?');
            $update->bind_param('sidsi', $productName, $quantity, $totalAmount, $purchasedOn, $id);
        } else {
            $update = $conn->prepare('UPDATE purchases SET supplier_id = ?, product_name = ?, quantity = ?, total_amount = ?, purchased_on = ? WHERE id = ?');
            $update->bind_param('isidsi', $supplierId, $productName, $quantity, $totalAmount, $purchasedOn, $id);
        }
        if ($update && $update->execute()) {
            setFlash('success', 'Purchase updated successfully.');
        } else {
            setFlash('error', 'Unable to update purchase.');
        }
    } else {
        setFlash('error', 'Unable to update purchase: database unavailable.');
    }
    header('Location: purchases.php');
    exit;
}

include 'includes/header.php';
?>
<div class="panel">
    <h3>Edit Purchase</h3>
    <?php if (!$purchase): ?>
        <div class="alert alert-error">Purchase not found.</div>
    <?php else: ?>
    <form method="post" class="form-grid">
        <div><label>Supplier</label><input type="text" name="supplier_name" value="<?= e($purchase['supplier_name'] ?? '') ?>"></div>
        <div><label>Product</label><input type="text" name="product_name" value="<?= e($purchase['product_name'] ?? '') ?>" required></div>
        <div><label>Quantity</label><input type="number" name="quantity" value="<?= e($purchase['quantity'] ?? 0) ?>" required></div>
        <div><label>Total Amount (₹)</label><input type="number" step="0.01" name="total_amount" value="<?= e($purchase['total_amount'] ?? 0) ?>" required></div>
        <div><label>Date</label><input type="date" name="purchased_on" value="<?= e($purchase['purchased_on'] ?? date('Y-m-d')) ?>" required></div>
        <div style="grid-column: 1 / -1;"><button type="submit">Save</button> <a href="purchases.php" class="btn">Cancel</a></div>
    </form>
    <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>