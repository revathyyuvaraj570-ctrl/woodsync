<?php
require_once 'config.php';
requireLogin();

$id = $_REQUEST['id'] ?? '';
$isLocal = strpos($id, 'local-') === 0;
$sale = null;

if ($isLocal) {
    $pending = $_SESSION['pending_sales'] ?? [];
    foreach ($pending as $p) {
        if (($p['id'] ?? '') === $id) {
            $sale = $p;
            break;
        }
    }
} else {
    if (!empty($id) && is_numeric($id) && $dbReady) {
        $stmt = $conn->prepare('SELECT s.*, c.name AS customer_name FROM sales s LEFT JOIN customers c ON c.id = s.customer_id WHERE s.id = ? LIMIT 1');
        if ($stmt) {
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $sale = $stmt->get_result()->fetch_assoc();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = trim($_POST['customer_name'] ?? '');
    $productName = trim($_POST['product_name'] ?? '');
    $quantity = (int)($_POST['quantity'] ?? 0);
    $totalAmount = (float)($_POST['total_amount'] ?? 0);
    $soldOn = trim($_POST['sold_on'] ?? date('Y-m-d'));

    if ($isLocal) {
        // update session
        $pending = &$_SESSION['pending_sales'];
        if (!empty($pending)) {
            foreach ($pending as $k => $p) {
                if (($p['id'] ?? '') === $id) {
                    $pending[$k]['customer_name'] = $customerName;
                    $pending[$k]['product_name'] = $productName;
                    $pending[$k]['quantity'] = $quantity;
                    $pending[$k]['total_amount'] = $totalAmount;
                    $pending[$k]['sold_on'] = $soldOn;
                    setFlash('success', 'Local sale updated.');
                    break;
                }
            }
        }
    } else {
        if ($dbReady && is_numeric($id)) {
            // ensure customer exists or create
            $customerId = null;
            if ($customerName !== '') {
                $cChk = $conn->prepare('SELECT id FROM customers WHERE name = ? LIMIT 1');
                if ($cChk) {
                    $cChk->bind_param('s', $customerName);
                    $cChk->execute();
                    $crow = $cChk->get_result()->fetch_assoc();
                    if ($crow) $customerId = (int)$crow['id'];
                    else {
                        $cIns = $conn->prepare('INSERT INTO customers (name) VALUES (?)');
                        if ($cIns) { $cIns->bind_param('s', $customerName); $cIns->execute(); $customerId = (int)$cIns->insert_id; }
                    }
                }
            }
            if ($customerId === null) {
                $up = $conn->prepare('UPDATE sales SET product_name=?, quantity=?, total_amount=?, sold_on=? WHERE id=?');
                if ($up) { $up->bind_param('sidsi', $productName, $quantity, $totalAmount, $soldOn, $id); $up->execute(); }
            } else {
                $up = $conn->prepare('UPDATE sales SET customer_id=?, product_name=?, quantity=?, total_amount=?, sold_on=? WHERE id=?');
                if ($up) { $up->bind_param('isidsi', $customerId, $productName, $quantity, $totalAmount, $soldOn, $id); $up->execute(); }
            }
            setFlash('success', 'Sale updated.');
        } else {
            setFlash('error', 'Unable to update sale: database unavailable.');
        }
    }
    header('Location: sales.php');
    exit;
}

include 'includes/header.php';
?>
<div class="panel">
    <h3>Edit Sale</h3>
    <?php if (!$sale): ?>
        <div class="alert alert-error">Sale not found.</div>
    <?php else: ?>
    <form method="post" class="form-grid">
        <div><label>Customer</label><input type="text" name="customer_name" value="<?= e($sale['customer_name'] ?? '') ?>"></div>
        <div><label>Product</label><input type="text" name="product_name" value="<?= e($sale['product_name'] ?? '') ?>" required></div>
        <div><label>Quantity</label><input type="number" name="quantity" value="<?= e($sale['quantity'] ?? 0) ?>" required></div>
        <div><label>Total Amount (₹)</label><input type="number" step="0.01" name="total_amount" value="<?= e($sale['total_amount'] ?? 0) ?>" required></div>
        <div><label>Date</label><input type="date" name="sold_on" value="<?= e($sale['sold_on'] ?? date('Y-m-d')) ?>" required></div>
        <div style="grid-column:1 / -1;">
            <button type="submit">Save</button>
            <a href="sales.php" class="btn">Cancel</a>
        </div>
    </form>
    <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
