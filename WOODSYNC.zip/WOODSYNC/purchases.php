<?php
require_once 'config.php';
requireLogin();
$page = 'purchases';

$submittedPurchase = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplierName = trim($_POST['supplier_name'] ?? '');
    $productName = trim($_POST['product_name'] ?? '');
    $quantity = (int)($_POST['quantity'] ?? 0);
    $totalAmount = (float)($_POST['total_amount'] ?? 0);
    $purchasedOn = trim($_POST['purchased_on'] ?? date('Y-m-d'));

    $saved = false;
    $saveError = null;

    if ($dbReady) {
        $supplierId = null;
        if ($supplierName !== '') {
            $supplierCheck = $conn->prepare('SELECT id FROM suppliers WHERE name = ? LIMIT 1');
            if ($supplierCheck) {
                $supplierCheck->bind_param('s', $supplierName);
                $supplierCheck->execute();
                $supplierRow = $supplierCheck->get_result()->fetch_assoc();
                if ($supplierRow) {
                    $supplierId = (int)$supplierRow['id'];
                } else {
                    $supplierInsert = $conn->prepare('INSERT INTO suppliers (name) VALUES (?)');
                    if ($supplierInsert) {
                        $supplierInsert->bind_param('s', $supplierName);
                        $supplierInsert->execute();
                        $supplierId = (int)$supplierInsert->insert_id;
                    }
                }
            }
        }

        if ($supplierId === null) {
            $stmt = $conn->prepare('INSERT INTO purchases (product_name, quantity, total_amount, purchased_on) VALUES (?, ?, ?, ?)');
            $stmt->bind_param('sids', $productName, $quantity, $totalAmount, $purchasedOn);
        } else {
            $stmt = $conn->prepare('INSERT INTO purchases (supplier_id, product_name, quantity, total_amount, purchased_on) VALUES (?, ?, ?, ?, ?)');
            $stmt->bind_param('isids', $supplierId, $productName, $quantity, $totalAmount, $purchasedOn);
        }

        if ($stmt && $stmt->execute()) {
            $saved = true;
        } else {
            $saveError = $stmt ? $stmt->error : 'Unable to save purchase.';
        }
    } else {
        $saveError = $dbError ?: 'Database is unavailable.';
    }

    if ($saved) {
        $submittedPurchase = [
            'id' => 'db-' . time(),
            'supplier_name' => $supplierName !== '' ? $supplierName : 'Unknown supplier',
            'product_name' => $productName,
            'quantity' => $quantity,
            'total_amount' => $totalAmount,
            'purchased_on' => $purchasedOn,
            'saved_locally' => false
        ];
        setFlash('success', 'Purchase recorded.');
    } else {
        $submittedPurchase = [
            'id' => 'local-' . time(),
            'supplier_name' => $supplierName !== '' ? $supplierName : 'Unknown supplier',
            'product_name' => $productName,
            'quantity' => $quantity,
            'total_amount' => $totalAmount,
            'purchased_on' => $purchasedOn,
            'saved_locally' => true
        ];
        $_SESSION['pending_purchases'][] = $submittedPurchase;
        setFlash('error', 'Saved locally on this page because the database is unavailable.');
    }
}

if (isset($_GET['delete_id'])) {
    $deleteId = $_GET['delete_id'];
    if (is_numeric($deleteId) && $dbReady) {
        $deleteStmt = $conn->prepare('DELETE FROM purchases WHERE id = ?');
        if ($deleteStmt) {
            $deleteStmt->bind_param('i', $deleteId);
            if ($deleteStmt->execute()) {
                setFlash('success', 'Purchase deleted successfully.');
            } else {
                setFlash('error', 'Unable to delete purchase.');
            }
        }
    } elseif (strpos((string)$deleteId, 'local-') === 0) {
        $_SESSION['pending_purchases'] = array_values(array_filter(
            $_SESSION['pending_purchases'] ?? [],
            function ($purchase) use ($deleteId) {
                return ($purchase['id'] ?? '') !== $deleteId;
            }
        ));
        setFlash('success', 'Local purchase deleted successfully.');
    }
    header('Location: purchases.php');
    exit;
}

$suppliersResult = $dbReady ? $conn->query('SELECT * FROM suppliers ORDER BY name') : false;
$suppliers = [];
if ($suppliersResult) {
    while ($supplier = $suppliersResult->fetch_assoc()) {
        $suppliers[] = $supplier;
    }
}
$purchasesResult = $dbReady ? $conn->query('SELECT p.*, s.name as supplier_name FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id ORDER BY p.id ASC') : false;
$purchases = [];
if ($purchasesResult) {
    while ($purchase = $purchasesResult->fetch_assoc()) {
        $purchases[] = $purchase;
    }
}
$pendingPurchases = $_SESSION['pending_purchases'] ?? [];
if ($submittedPurchase) {
    $pendingPurchases[] = $submittedPurchase;
    $_SESSION['pending_purchases'] = $pendingPurchases;
}
if (!empty($pendingPurchases)) {
    $purchases = array_merge($pendingPurchases, $purchases);
}
if (empty($purchases)) {
    $purchases = [];
}
include 'includes/header.php';
?>
<div class="panel">
    <h3>Add Purchase</h3>
    <form method="post" class="form-grid">
        <div><label>Supplier</label><input type="text" name="supplier_name" list="suppliers-list" placeholder="Type supplier name" autocomplete="off"></div>
        <datalist id="suppliers-list">
            <?php foreach ($suppliers as $supplier): ?>
                <option value="<?= e($supplier['name']) ?>"><?= e($supplier['name']) ?></option>
            <?php endforeach; ?>
        </datalist>
        <div><label>Product</label><input type="text" name="product_name" required></div>
        <div><label>Quantity</label><input type="number" name="quantity" required></div>
        <div><label>Total Amount (₹)</label><input type="number" step="0.01" name="total_amount" required></div>
        <div><label>Date</label><input type="date" name="purchased_on" value="<?= date('Y-m-d') ?>" required></div>
        <div style="grid-column: 1 / -1;"><button type="submit">Save Purchase</button></div>
    </form>
</div>

<div class="panel">
    <h3>Purchase History</h3>
    <div class="table-wrap">
        <table>
            <thead><tr><th>#</th><th>Supplier</th><th>Product</th><th>Quantity</th><th>Total</th><th>Date</th><th>Actions</th></tr></thead>
            <tbody>
                <?php if (empty($purchases)): ?>
                    <tr><td colspan="7" style="text-align:center;">No purchase data yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($purchases as $row): ?>
                        <tr>
                            <td><?= e($row['id'] ?? 'local') ?></td>
                            <td><?= e($row['supplier_name'] ?? 'Unknown supplier') ?></td>
                            <td><?= e($row['product_name'] ?? '') ?></td>
                            <td><?= e($row['quantity'] ?? 0) ?></td>
                            <td>₹<?= e(number_format((float)($row['total_amount'] ?? 0), 2)) ?></td>
                            <td><?= e($row['purchased_on'] ?? date('Y-m-d')) ?></td>
                            <td class="row-actions">
                                <a class="action-btn edit" href="purchases_edit.php?id=<?= e($row['id'] ?? '') ?>">Edit</a>
                                <a class="action-btn delete" href="purchases.php?delete_id=<?= e($row['id'] ?? '') ?>" onclick="return confirm('Delete this purchase?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include 'includes/footer.php'; ?>