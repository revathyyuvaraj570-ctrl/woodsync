<?php
class ReportGenerator
{
    public static function buildPdfContent($data)
    {
        $lines = [];
        $lines[] = 'WoodSync ERP Executive Report';
        $lines[] = '=================================';
        $lines[] = 'Generated: ' . date('Y-m-d H:i:s');
        $lines[] = 'Prepared by: WoodSync ERP System';
        $lines[] = '';
        $lines[] = 'Financial Overview';
        $lines[] = '------------------';
        $lines[] = 'Total Sales:       ₹' . number_format((float)($data['sales_value'] ?? 0), 2);
        $lines[] = 'Total Purchases:   ₹' . number_format((float)($data['purchase_value'] ?? 0), 2);
        $lines[] = 'Inventory Value:   ₹' . number_format((float)($data['inventory_value'] ?? 0), 2);
        $lines[] = 'Employee Count:    ' . ($data['employee_count'] ?? 0);
        $lines[] = '';
        $lines[] = 'Operational Insight';
        $lines[] = '-------------------';
        $lines[] = ($data['summary'] ?? 'No summary available.');
        $lines[] = '';
        $lines[] = 'Key Recommendations';
        $lines[] = '-------------------';
        $lines[] = '- Prioritize replenishment of low-stock items with high turnover.';
        $lines[] = '- Monitor fast-moving timber and furniture SKUs closely this season.';
        $lines[] = '- Align procurement planning with current demand forecasts.';
        return implode("\n", $lines);
    }

    public static function savePdf($filePath, $content)
    {
        $lines = explode("\n", $content);
        $objects = [];
        $objects[] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objects[] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";

        $streamLines = [];
        $streamLines[] = 'BT';
        $streamLines[] = '/F1 12 Tf';
        $streamLines[] = '72 720 Td';

        foreach ($lines as $index => $line) {
            $escaped = str_replace('\\', '\\\\', $line);
            $escaped = str_replace('(', '\\(', $escaped);
            $escaped = str_replace(')', '\\)', $escaped);
            $streamLines[] = "(" . $escaped . ") Tj";
            if ($index < count($lines) - 1) {
                $streamLines[] = '0 -18 Td';
            }
        }

        $streamLines[] = 'ET';
        $contentStream = implode("\n", $streamLines);

        $objects[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>";
        $objects[] = "<< /Length " . strlen($contentStream) . " >>\nstream\n" . $contentStream . "\nendstream";
        $objects[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";

        $pdf = "%PDF-1.4\n";
        $offsets = [0];

        foreach ($objects as $index => $object) {
            $offsets[] = strlen($pdf);
            $pdf .= ($index + 1) . " 0 obj\n" . $object . "\nendobj\n";
        }

        $xrefPos = strlen($pdf);
        $pdf .= "xref\n0 6\n0000000000 65535 f \n";

        for ($i = 1; $i < count($offsets); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        $pdf .= "trailer\n";
        $pdf .= "<< /Root 1 0 R /Size 6 >>\n";
        $pdf .= "startxref\n";
        $pdf .= $xrefPos . "\n";
        $pdf .= "%%EOF";

        $result = file_put_contents($filePath, $pdf);
        return $result !== false && file_exists($filePath);
    }
}
